#pragma once
#include "strategy.h"

class SMAStrategy : public Strategy {
    int period;

public:
    SMAStrategy(int p) : period(p) {}

    double calculateSMA(const std::vector<PriceData>& prices, int currentIndex) {
        if (currentIndex < period) return -1.0;

        double sum = 0.0;
        for (int i = currentIndex - period; i < currentIndex; ++i)
            sum += prices[i].close;
        return sum / period;
    }

    Signal generateSignal(const std::vector<PriceData>& prices, int currentIndex, bool holding) override {
        double sma = calculateSMA(prices, currentIndex);
        if (sma < 0) return Signal::HOLD;

        double currentClose = prices[currentIndex].close;

        if (currentClose > sma && !holding)
            return Signal::BUY;
        else if (currentClose < sma && holding)
            return Signal::SELL;
        else
            return Signal::HOLD;
    }

    std::string name() override {
        return "SMA Strategy";
    }
};
