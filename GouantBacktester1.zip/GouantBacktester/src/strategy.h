#pragma once
#include <string>
#include <vector>
#include "price_data.h"

enum class Signal {
    BUY,
    SELL,
    HOLD
};

class Strategy {
public:
    virtual ~Strategy() {}
    virtual Signal generateSignal(const std::vector<PriceData>& prices, int currentIndex, bool holding) = 0;
    virtual std::string name() = 0;
};
