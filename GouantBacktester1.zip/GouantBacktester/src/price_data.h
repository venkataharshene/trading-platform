#pragma once
#include <string>

struct PriceData {
    std::string timestamp;
    double open, high, low, close, volume;
};
