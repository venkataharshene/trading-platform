#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <memory>
#include <thread> 
#include <cmath>
#include "strategy.h"
#include "sma_strategy.h"
#include "price_data.h"


std::vector<PriceData> loadCSV(const std::string& filename) {
    std::vector<PriceData> data;
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << " Could not open file: " << filename << std::endl;
        return data;
    }

    std::string line;
    std::getline(file, line); // skip header

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string cell;
        PriceData row;

        std::getline(ss, row.timestamp, ',');
        std::getline(ss, cell, ','); row.open = std::stod(cell);
        std::getline(ss, cell, ','); row.high = std::stod(cell);
        std::getline(ss, cell, ','); row.low = std::stod(cell);
        std::getline(ss, cell, ','); row.close = std::stod(cell);
        std::getline(ss, cell, ','); row.volume = std::stod(cell);

        data.push_back(row);
    }

    return data;
}

struct Trade {
    std::string type;      // "BUY" or "SELL"
    std::string date;
    double price;
    double profit;
};

#include <fstream>  // Add this at the top of your file if not present

void saveTradeLogToCSV(const std::vector<Trade>& tradeLog, const std::string& filename) {
    std::ofstream file(filename);  // create a file

    if (!file.is_open()) {
        std::cerr << "Could not create file: " << filename << std::endl;
        return;
    }

    // write the column names
    file << "type,date,price,profit\n";

    // write each trade
    for (const auto& t : tradeLog) {
        file << t.type << "," << t.date << "," << t.price << "," << t.profit << "\n";
    }

    file.close();
    std::cout << " Trade log saved to: " << filename << std::endl;
}

void simulateLiveTrading(const std::vector<PriceData>& prices, Strategy& strategy);

double calculateSMA(const std::vector<PriceData>& prices, int currentIndex, int period) {
    if (currentIndex < period) return -1.0; // not enough data

    double sum = 0.0;
    for (int i = currentIndex - period; i < currentIndex; ++i) {
        sum += prices[i].close;
    }
    return sum / period;
}

// Apply a fixed slippage of 0.05% to simulate realistic market impact
double applySlippage(double price, bool isBuy) {
    double slippageRate = 0.0005;  // 0.05%
    if (isBuy) {
        return price * (1.0 + slippageRate);  // You pay slightly more when buying
    } else {
        return price * (1.0 - slippageRate);  // You get slightly less when selling
    }
}
double calculateSharpeRatio(const std::vector<double>& returns, double riskFreeRate = 0.0) {
    if (returns.empty()) return 0.0;

    double sum = 0.0;
    for (double r : returns) sum += r;
    double mean = sum / returns.size();

    double variance = 0.0;
    for (double r : returns) variance += (r - mean) * (r - mean);
    variance /= returns.size();

    double stddev = std::sqrt(variance);
    return stddev != 0 ? (mean - riskFreeRate) / stddev : 0.0;
}
std::vector<double> calculateDailyReturns(const std::vector<PriceData>& prices) {
    std::vector<double> returns;
    for (size_t i = 1; i < prices.size(); ++i) {
        double prevClose = prices[i - 1].close;
        double currClose = prices[i].close;
        if (prevClose != 0) {
            double dailyReturn = (currClose - prevClose) / prevClose;
            returns.push_back(dailyReturn);
        }
    }
    return returns;
}

double calculateMaxDrawdown(const std::vector<PriceData>& prices) {
    double maxDrawdown = 0.0;
    double peak = prices[0].close;

    for (const auto& price : prices) {
        if (price.close > peak) {
            peak = price.close;
        }
        double drawdown = (peak - price.close) / peak;
        if (drawdown > maxDrawdown) {
            maxDrawdown = drawdown;
        }
    }

    return maxDrawdown * 100.0; // convert to percentage
}


int main() {
    std::string path = "../data/btc_usd.csv";
    std::vector<PriceData> prices = loadCSV(path);
    std::unique_ptr<Strategy> strategy = std::make_unique<SMAStrategy>(3);
    if (prices.size() < 2) {
        std::cout << "Not enough data to simulate.\n";
        return 1;
    }

    std::cout << "Loaded " << prices.size() << " rows.\n";

    double cash = 1000.0;
    double position = 0.0;
    bool holding = false;
    std::vector<Trade> tradeLog;

    for (size_t i = 1; i < prices.size(); ++i) {
        const PriceData& curr = prices[i];
        std::cout << curr.timestamp << " - Close: " << curr.close << " ";

        Signal signal = strategy->generateSignal(prices, i, holding);

        if (signal == Signal::BUY) {
            double entryPrice = applySlippage(curr.close, true);
            position = cash / entryPrice;
            cash = 0;

            holding = true;

            std::cout << "[BUY]\n";
            tradeLog.push_back({"BUY", curr.timestamp, entryPrice, 0});

        } else if (signal == Signal::SELL) {
            double exitPrice = applySlippage(curr.close, false);
            cash = position * exitPrice;
            double profit = (exitPrice - tradeLog.back().price) * position;

            position = 0;
            holding = false;

            std::cout << "[SELL] Profit: " << profit << "\n";
            tradeLog.push_back({"SELL", curr.timestamp, exitPrice, profit});

        } else {
            std::cout << "[HOLD]\n";
        }
    }


    if (holding) {
        // Final forced sell at last close
        double finalRawPrice = prices.back().close;
        double finalPrice = applySlippage(prices.back().close, false);
        double profit = (finalPrice - tradeLog.back().price) * position;

        cash = position * finalPrice;
        Trade t;
        t.type = "SELL";
        t.date = prices.back().timestamp;
        t.price = finalPrice;
        t.profit = profit;
        tradeLog.push_back(t);

        std::cout << "Forced [SELL] on last day: Rs. " << profit << "\n";
    }

    // Final Balance
    std::cout << "\nFinal Balance: Rs. " << cash << "\n\n";

    // Print Trade Log
    std::cout << "===== TRADE LOG =====\n";
    int winCount = 0;
    double totalProfit = 0;
    for (const auto& t : tradeLog) {
        std::cout << t.date << " - " << t.type << " @ Rs. " << t.price;
        if (t.type == "SELL") {
            std::cout << " | Profit: Rs. " << t.profit;
            totalProfit += t.profit;
            if (t.profit > 0) winCount++;
        }
        std::cout << "\n";
    }

    // Stats
    int numTrades = tradeLog.size() / 2; // Every BUY + SELL = 1 trade
    std::cout << "\n===== STATS =====\n";
    std::cout << "Total Trades: " << numTrades << "\n";
    std::cout << "Winning Trades: " << winCount << "\n";
    if (numTrades > 0)
        std::cout << "Win Rate: " << (100.0 * winCount / numTrades) << "%\n";
    std::cout << "Total Profit from trades: Rs. " << totalProfit << "\n";
    saveTradeLogToCSV(tradeLog, "../data/trades.csv");
    simulateLiveTrading(prices, *strategy);
    std::vector<double> dailyReturns = calculateDailyReturns(prices);
    double sharpeRatio = calculateSharpeRatio(dailyReturns);
    // Print performance metric
    std::cout << "\n===== PERFORMANCE METRICS =====\n";
    std::cout << "Sharpe Ratio: " << sharpeRatio << "\n";
    double maxDrawdown = calculateMaxDrawdown(prices);
    std::cout << "Max Drawdown: " << maxDrawdown << "%\n";


    return 0;
    
}
void simulateLiveTrading(const std::vector<PriceData>& prices, Strategy& strategy) {
    double cash = 1000.0;
    double position = 0.0;
    bool holding = false;

    std::vector<Trade> liveTrades;

    std::cout << "\n=== Starting Live Shadow Simulation ===\n";

    for (size_t i = 0; i < prices.size(); ++i) {
        double price = prices[i].close;
        Signal signal = strategy.generateSignal(prices, i, holding);

        std::cout << prices[i].timestamp << " | Price: " << price;

        if (signal == Signal::BUY && !holding) {
            double entryPrice = applySlippage(price, true);
            position = cash / entryPrice;
            cash = 0;
            holding = true;
            std::cout << " [LIVE BUY]";
            liveTrades.push_back({"BUY", prices[i].timestamp, entryPrice, 0});

        } else if (signal == Signal::SELL && holding) {
            double exitPrice = applySlippage(price, false);
            cash = position * exitPrice;
            double profit = (exitPrice - liveTrades.back().price) * position;
            position = 0;
            holding = false;
            std::cout << " [LIVE SELL] Profit: " << profit;
            liveTrades.push_back({"SELL", prices[i].timestamp, exitPrice, profit});

        } else {
            std::cout << " [LIVE HOLD]";
        }

        std::cout << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000)); // Simulate 1s delay
    }

    if (holding) {
        double finalPrice = applySlippage(prices.back().close, false);
        cash = position * finalPrice;
        double profit = (finalPrice - liveTrades.back().price) * position;
        liveTrades.push_back({"SELL", prices.back().timestamp, finalPrice, profit});
        std::cout << "Forced [LIVE SELL] on last row. Profit: " << profit << std::endl;
    }

    std::cout << "\nLive Simulation Final Balance: Rs. " << cash << std::endl;
    saveTradeLogToCSV(liveTrades, "../data/live_trades.csv");

    // === LIVE STATS ===
    std::cout << "\n===== LIVE STATS =====\n";
    int totalTrades = liveTrades.size() / 2;
    int winningTrades = 0;
    double totalProfit = 0.0;

    for (const auto& t : liveTrades) {
        if (t.type == "SELL") {
            totalProfit += t.profit;
            if (t.profit > 0) winningTrades++;
        }
    }

    std::cout << "Total Trades: " << totalTrades << "\n";
    std::cout << "Winning Trades: " << winningTrades << "\n";
    if (totalTrades > 0)
        std::cout << "Win Rate: " << (100.0 * winningTrades / totalTrades) << "%\n";
    std::cout << "Total Profit from trades: Rs. " << totalProfit << "\n";
}



